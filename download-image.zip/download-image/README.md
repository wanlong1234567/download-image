# download-image

+ 下载项目
+ 点击hmtl文件即可测试下载功能
+ 可能IE会本地其服务才可实现下载
  - 推荐使用anywhere本地起一个简单的服务